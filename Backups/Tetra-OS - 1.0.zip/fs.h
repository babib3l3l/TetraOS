#ifndef FS_H
#define FS_H

#include <stdint.h>
#include <stddef.h>

// Déclaration anticipée si nécessaire
struct FSNode;
struct FSTable;

#define FS_TABLE_LBA         2048u
#define FS_TABLE_SECTORS     6144u
#define FS_DATA_BASE_LBA     8192u
#define FS_MAGIC             0x544F5346
#define FS_MAX_NODES         256
#define FS_NAME_LEN          32
#define FS_MAX_CHILDREN      16

typedef struct FSNode {
    char     name[FS_NAME_LEN];
    uint8_t  is_dir;
    uint8_t  _pad[3];
    uint32_t parent;
    uint32_t children[FS_MAX_CHILDREN];
    uint32_t child_count;
    uint32_t data_start_lba;
    uint32_t size_bytes;
    uint32_t magic;
} FSNode;

typedef struct FSTable {
    uint32_t magic;
    uint32_t node_count;
    FSNode   nodes[FS_MAX_NODES];
} FSTable;

extern FSTable g_fs;
extern uint32_t g_cwd;

// Prototypes des fonctions
void fs_init(void);
int fs_flush(void);
void fs_format(void);
int fs_mkdir(const char* name);
int fs_add(const char* name);
int fs_cd(const char* name);
void fs_pwd(void);
void fs_ls(void);
int fs_write_file(const char* name, const uint8_t* data, uint32_t size);
int fs_read_file(const char* name, uint8_t* out, uint32_t max_len);
int fs_delete(const char* name);
void fs_list(void);
int fs_find_in_dir(uint32_t dir_idx, const char* name);
uint32_t fs_next_free_lba(void);
int fs_find(const char* name);


#endif