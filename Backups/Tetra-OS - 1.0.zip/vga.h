#ifndef VGA_H
#define VGA_H

void clear_screen();
void print_char(char c);
void print_string(const char* str);

#endif
