#pragma once
#include <stdint.h>
#include <stddef.h>
void mem_boot_init(uintptr_t phys_base, size_t phys_size);
